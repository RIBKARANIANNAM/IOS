//
//  ResultViewController.swift
//  MVCDiscountApp
//
//  Created by Annam,Ribkarani on 3/30/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var displayOutlet: UILabel!
    @IBOutlet weak var displayDiscRateOL: UILabel!
    
    @IBOutlet weak var resultOL: UILabel!
    
    var destinationAmount = ""
    var destinationDiscRate = ""
    var destinationResult = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayOutlet.text =
        displayOutlet.text! + destinationAmount;
        displayDiscRateOL.text =
        displayDiscRateOL.text! +  destinationDiscRate;
        resultOL.text =  resultOL.text! + destinationResult;
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
