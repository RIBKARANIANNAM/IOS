//
//  ViewController.swift
//  MVCDiscountApp
//
//  Created by Annam,Ribkarani on 3/30/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AmountOutlet: UITextField!
    
    @IBOutlet weak var DiscountOutlet:
    UITextField!
    
    var priceAfterDiscount = 0.0
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func CalBtn(_ sender: Any) {
        //read the text and convert it to double
        
        var amount = Double(AmountOutlet.text!)
        print(amount!)
        var discRate = Double(DiscountOutlet.text!)
        print(discRate!)
        
        
        priceAfterDiscount = amount! - (amount!*discRate!/100)
        print(priceAfterDiscount)
    
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    // create a transistion
        
        var transition = segue.identifier
        //create destination
        if(transition == "ResultSegue"){
            //reach the destination
            var destination = segue.destination
            as! ResultViewController
            
            destination.destinationAmount = AmountOutlet.text!
            destination.destinationDiscRate = DiscountOutlet.text!
            destination.destinationResult = String(priceAfterDiscount)
            
            
        }
    }
    
    
    
}

